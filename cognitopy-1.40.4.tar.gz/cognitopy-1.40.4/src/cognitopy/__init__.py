# flake8: noqa
from .cognitopy import CognitoPy
