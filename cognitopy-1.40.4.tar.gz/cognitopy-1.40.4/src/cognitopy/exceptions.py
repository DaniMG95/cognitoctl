class ExceptionAuthCognito(Exception):
    pass


class ExceptionTokenExpired(Exception):
    pass


class ExceptionConnectionCognito(Exception):
    pass


class ExceptionJWTCognito(Exception):
    pass
